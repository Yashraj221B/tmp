#include <iostream>
using namespace std;

long long power2(int n) {
    long long result = 1;
    for (int i = 0; i < n; i++) {
        result = result * 2;
    }
    return result;
}

void printIP(long long n) {
    cout << (n / 16777216) % 256 << ".";
    cout << (n / 65536) % 256 << ".";
    cout << (n / 256) % 256 << ".";
    cout << n % 256;
}

void printBinary(long long n) {
    long long parts[4] = {16777216, 65536, 256, 1};
    for (int i = 0; i < 4; i++) {
        int octet = (n / parts[i]) % 256;
        for (int bit = 128; bit >= 1; bit = bit / 2) {
            if (octet >= bit) {
                cout << "1";
                octet = octet - bit;
            } else {
                cout << "0";
            }
        }
        if (i < 3) {
            cout << ".";
        }
    }
}

char findClass(int first) {
    if (first < 128) return 'A';
    if (first < 192) return 'B';
    if (first < 224) return 'C';
    if (first < 240) return 'D';
    return 'E';
}

bool isPrivate(int a, int b) {
    if (a == 10) return true;
    if (a == 172 && b >= 16 && b <= 31) return true;
    if (a == 192 && b == 168) return true;
    return false;
}

int main() {
    char again;

    do {
        int a, b, c, d, prefix;
        char dot1, dot2, dot3, slash;

        cout << "Enter IP address with prefix (example 192.168.10.37/26): ";
        cin >> a >> dot1 >> b >> dot2 >> c >> dot3 >> d >> slash >> prefix;

        if (cin.fail() || dot1 != '.' || dot2 != '.' || dot3 != '.' || slash != '/') {
            cout << "Invalid format.\n";
            cin.clear();
            cin.ignore(1000, '\n');
        } else if (a < 0 || a > 255 || b < 0 || b > 255 || c < 0 || c > 255 || d < 0 || d > 255) {
            cout << "Each part of the IP address must be between 0 and 255.\n";
        } else if (prefix < 0 || prefix > 32) {
            cout << "Prefix must be between 0 and 32.\n";
        } else {
            long long ip = a * 16777216LL + b * 65536LL + c * 256LL + d;
            long long blockSize = power2(32 - prefix);
            long long mask = 4294967296LL - blockSize;
            long long wildcard = blockSize - 1;
            long long network = ip / blockSize * blockSize;
            long long broadcast = network + wildcard;
            long long firstHost = network + 1;
            long long lastHost = broadcast - 1;
            long long usableHosts = blockSize - 2;

            if (prefix == 31) {
                firstHost = network;
                lastHost = broadcast;
                usableHosts = 2;
            } else if (prefix == 32) {
                firstHost = network;
                lastHost = network;
                usableHosts = 1;
            }

            cout << "\n----- Result -----\n";
            cout << "IP Address        : "; printIP(ip); cout << endl;
            cout << "Binary IP         : "; printBinary(ip); cout << endl;
            cout << "Class             : " << findClass(a) << endl;
            if (isPrivate(a, b)) {
                cout << "Type              : Private\n";
            } else {
                cout << "Type              : Public\n";
            }
            cout << "Subnet Mask       : "; printIP(mask); cout << endl;
            cout << "Binary Mask       : "; printBinary(mask); cout << endl;
            cout << "Wildcard Mask     : "; printIP(wildcard); cout << endl;
            cout << "Network Address   : "; printIP(network); cout << endl;
            cout << "Broadcast Address : "; printIP(broadcast); cout << endl;
            cout << "First Host        : "; printIP(firstHost); cout << endl;
            cout << "Last Host         : "; printIP(lastHost); cout << endl;
            cout << "Total Addresses   : " << blockSize << endl;
            cout << "Usable Hosts      : " << usableHosts << endl;

            char choice;
            cout << "\nDo you want to divide this network into subnets? (y/n): ";
            cin >> choice;

            if (choice == 'y' || choice == 'Y') {
                int n;
                cout << "Enter number of subnets required: ";
                cin >> n;

                int bits = 0;
                long long count = 1;
                while (count < n) {
                    count = count * 2;
                    bits++;
                }

                int newPrefix = prefix + bits;

                if (n < 1 || newPrefix > 30) {
                    cout << "This network cannot be divided into " << n << " subnets.\n";
                } else {
                    long long newSize = power2(32 - newPrefix);

                    cout << "\nNew prefix        : /" << newPrefix << endl;
                    cout << "New subnet mask   : "; printIP(4294967296LL - newSize); cout << endl;
                    cout << "Hosts per subnet  : " << newSize - 2 << endl << endl;

                    for (int i = 0; i < count; i++) {
                        long long start = network + i * newSize;
                        long long end = start + newSize - 1;

                        cout << "Subnet " << i + 1 << endl;
                        cout << "  Network    : "; printIP(start); cout << endl;
                        cout << "  Host range : "; printIP(start + 1); cout << " - "; printIP(end - 1); cout << endl;
                        cout << "  Broadcast  : "; printIP(end); cout << endl;
                    }
                }
            }
        }

        cout << "\nDo you want to try another? (y/n): ";
        cin >> again;

    } while (again == 'y' || again == 'Y');

    return 0;
}