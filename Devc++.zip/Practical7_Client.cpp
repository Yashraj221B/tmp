#include <iostream>
#include <string>
#include <cstring>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
using namespace std;

#define PORT 8731

void tcpClient(string ip) {
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        cout << "Socket creation failed!" << endl;
        return;
    }

    sockaddr_in server;
    memset(&server, 0, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(PORT);
    server.sin_addr.s_addr = inet_addr(ip.c_str());

    if (connect(sock, (sockaddr*)&server, sizeof(server)) < 0) {
        cout << "Connection failed! Is the TCP server running?" << endl;
        close(sock);
        return;
    }
    cout << "Connected to TCP Server " << ip << ":" << PORT << endl;

    char buffer[1024];
    while (true) {
        string message;
        cout << "Enter message (exit to quit): ";
        getline(cin, message);

        send(sock, message.c_str(), message.length(), 0);
        if (message == "exit")
            break;

        int bytes = recv(sock, buffer, 1023, 0);
        if (bytes <= 0)
            break;
        buffer[bytes] = '\0';
        cout << "Server: " << buffer << endl;
    }

    close(sock);
    cout << "TCP client closed." << endl;
}

void udpClient(string ip) {
    int sock = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock < 0) {
        cout << "Socket creation failed!" << endl;
        return;
    }

    sockaddr_in server, from;
    memset(&server, 0, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(PORT);
    server.sin_addr.s_addr = inet_addr(ip.c_str());

    cout << "UDP Client started, sending to " << ip << ":" << PORT << endl;

    char buffer[1024];
    while (true) {
        string message;
        cout << "Enter message (exit to quit): ";
        getline(cin, message);

        sendto(sock, message.c_str(), message.length(), 0,
               (sockaddr*)&server, sizeof(server));

        socklen_t fromSize = sizeof(from);
        int bytes = recvfrom(sock, buffer, 1023, 0, (sockaddr*)&from, &fromSize);
        if (bytes < 0)
            break;
        buffer[bytes] = '\0';
        cout << "Server: " << buffer << endl;

        if (message == "exit")
            break;
    }

    close(sock);
    cout << "UDP client closed." << endl;
}

int main() {
    int choice;
    string ip = "127.0.0.1";
    do {
        cout << "\n===== CLIENT MENU =====" << endl;
        cout << "1. TCP Client" << endl;
        cout << "2. UDP Client" << endl;
        cout << "3. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;
        cin.ignore(1000, '\n');

        if (choice == 1)
            tcpClient(ip);
        else if (choice == 2)
            udpClient(ip);
        else if (choice != 3)
            cout << "Invalid choice, try again." << endl;
    } while (choice != 3);

    return 0;
}
