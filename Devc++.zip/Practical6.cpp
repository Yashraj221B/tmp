#include <iostream>
using namespace std;

#define MAX 10
#define INF 9999

int n;
int cost[MAX][MAX];

void distanceVector() {
    int dist[MAX][MAX];
    int next[MAX][MAX];

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            dist[i][j] = cost[i][j];
            if (i == j) next[i][j] = i;
            else if (cost[i][j] < INF) next[i][j] = j;
            else next[i][j] = -1;
        }
    }

    int round = 0;
    bool changed = true;
    while (changed) {
        changed = false;
        round++;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < n; k++) {
                    if (k != i && cost[i][k] < INF && dist[k][j] < INF) {
                        if (cost[i][k] + dist[k][j] < dist[i][j]) {
                            dist[i][j] = cost[i][k] + dist[k][j];
                            next[i][j] = k;
                            changed = true;
                        }
                    }
                }
            }
        }
    }

    cout << "\n--- Distance Vector Routing (converged after " << round << " rounds) ---\n";
    for (int i = 0; i < n; i++) {
        cout << "\nRouting table of Router " << i + 1 << endl;
        cout << "Destination\tCost\tNext Hop\n";
        for (int j = 0; j < n; j++) {
            cout << j + 1 << "\t\t";
            if (dist[i][j] >= INF) cout << "INF\t-";
            else cout << dist[i][j] << "\t" << next[i][j] + 1;
            cout << endl;
        }
    }
}

void linkState() {
    int src;
    cout << "\nEnter source router (1 to " << n << "): ";
    cin >> src;
    if (src < 1 || src > n) {
        cout << "Invalid router number.\n";
        return;
    }
    src--;

    int dist[MAX], parent[MAX];
    bool done[MAX];
    for (int i = 0; i < n; i++) {
        dist[i] = INF;
        parent[i] = -1;
        done[i] = false;
    }
    dist[src] = 0;

    for (int count = 0; count < n; count++) {
        int u = -1;
        for (int i = 0; i < n; i++) {
            if (!done[i] && dist[i] < INF && (u == -1 || dist[i] < dist[u]))
                u = i;
        }
        if (u == -1) break;
        done[u] = true;

        for (int v = 0; v < n; v++) {
            if (!done[v] && cost[u][v] < INF && dist[u] + cost[u][v] < dist[v]) {
                dist[v] = dist[u] + cost[u][v];
                parent[v] = u;
            }
        }
    }

    cout << "\n--- Link State Routing (Dijkstra) ---\n";
    cout << "Source Router: " << src + 1 << endl;
    cout << "Destination\tCost\tPath\n";
    for (int i = 0; i < n; i++) {
        cout << i + 1 << "\t\t";
        if (dist[i] >= INF) {
            cout << "INF\tNo path\n";
            continue;
        }
        cout << dist[i] << "\t";

        int path[MAX], len = 0;
        for (int x = i; x != -1; x = parent[x])
            path[len++] = x;
        for (int j = len - 1; j >= 0; j--) {
            cout << path[j] + 1;
            if (j > 0) cout << " -> ";
        }
        cout << endl;
    }
}

int main() {
    int choice;
    cout << "===== Routing Algorithms =====\n";
    cout << "Enter number of routers (max " << MAX << "): ";
    cin >> n;
    if (n < 1 || n > MAX) {
        cout << "Invalid number of routers.\n";
        return 0;
    }

    cout << "Enter cost matrix (" << INF << " for no direct link)\n";
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            cout << "Cost from Router " << i + 1 << " to Router " << j + 1 << ": ";
            cin >> cost[i][j];
        }
    }

    do {
        cout << "\n===== MENU =====\n";
        cout << "1. Distance Vector Routing\n";
        cout << "2. Link State Routing\n";
        cout << "3. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 1) distanceVector();
        else if (choice == 2) linkState();
        else if (choice != 3) cout << "Invalid choice, try again.\n";
    } while (choice != 3);

    return 0;
}
