#include <iostream>
using namespace std;

void stopAndWait() {
    int n, ack;

    cout << "Enter number of frames: ";
    cin >> n;

    for (int i = 1; i <= n; i++) {
        cout << "\nSending Frame " << i << "..." << endl;

        cout << "Enter ACK (1 = received, 0 = lost): ";
        cin >> ack;

        while (ack == 0) {
            cout << "ACK lost for Frame " << i << endl;
            cout << "Timeout, retransmitting Frame " << i << "..." << endl;

            cout << "Enter ACK (1 = received, 0 = lost): ";
            cin >> ack;
        }

        cout << "ACK received for Frame " << i << endl;
    }

    cout << "\nAll frames transmitted successfully." << endl;
}

void goBackN() {
    int n, window, ack;

    cout << "Enter number of frames: ";
    cin >> n;

    cout << "Enter window size: ";
    cin >> window;

    int base = 1, nextSeq = 1, highest = 0;

    while (base <= n) {
        while (nextSeq < base + window && nextSeq <= n) {
            if (nextSeq <= highest) {
                cout << "Retransmitting Frame " << nextSeq << endl;
            } else {
                cout << "Sending Frame " << nextSeq << endl;
                highest = nextSeq;
            }
            nextSeq++;
        }

        cout << "Enter ACK for Frame " << base << " (1 = received, 0 = lost): ";
        cin >> ack;

        if (ack == 1) {
            cout << "ACK " << base << " received" << endl;
            base++;

            if (base <= n) {
                int end = base + window - 1;

                if (end > n)
                    end = n;

                cout << "Window slides to Frame " << base << " - " << end << endl;
            }
        } else {
            cout << "Timeout for Frame " << base << endl;

            for (int j = base + 1; j < nextSeq; j++)
                cout << "Frame " << j << " discarded by receiver (out of order)" << endl;

            cout << "Go back to Frame " << base << endl;
            nextSeq = base;
        }
    }

    cout << "\nAll frames transmitted successfully." << endl;
}

void selectiveRepeat() {
    int n, window;
    int ack[101];

    cout << "Enter number of frames: ";
    cin >> n;

    cout << "Enter window size: ";
    cin >> window;

    for (int i = 1; i <= n; i++)
        ack[i] = 0;

    int start = 1;

    while (start <= n) {
        int end = start + window - 1;

        if (end > n)
            end = n;

        cout << "\nSending frames " << start << " to " << end << endl;

        for (int i = start; i <= end; i++)
            cout << "Frame " << i << " sent." << endl;

        for (int i = start; i <= end; i++) {
            cout << "Enter ACK for Frame " << i << " (1 = received, 0 = lost): ";
            cin >> ack[i];
        }

        for (int i = start; i <= end; i++) {
            while (ack[i] == 0) {
                cout << "Frame " << i << " lost." << endl;
                cout << "Retransmitting Frame " << i << "..." << endl;

                cout << "Enter ACK for Frame " << i << " (1 = received, 0 = lost): ";
                cin >> ack[i];
            }
        }

        while (start <= n && ack[start] == 1)
            start++;

        if (start <= n)
            cout << "Window moves to Frame " << start << endl;
    }

    cout << "\nAll frames transmitted successfully." << endl;
}

int main() {
    int choice;

    do {
        cout << "\n===== SLIDING WINDOW PROTOCOLS =====" << endl;
        cout << "1. Stop and Wait ARQ" << endl;
        cout << "2. Go Back N ARQ" << endl;
        cout << "3. Selective Repeat ARQ" << endl;
        cout << "4. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        cout << endl;

        switch (choice) {
            case 1:
                stopAndWait();
                break;
            case 2:
                goBackN();
                break;
            case 3:
                selectiveRepeat();
                break;
            case 4:
                cout << "Exiting program..." << endl;
                break;
            default:
                cout << "Invalid choice! Try again." << endl;
        }
    } while (choice != 4);

    return 0;
}