#include <iostream>
#include <string>
#include <cstring>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
using namespace std;

#define PORT 8731

void tcpServer() {
    int serverSock = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSock < 0) {
        cout << "Socket creation failed!" << endl;
        return;
    }

    int opt = 1;
    setsockopt(serverSock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    sockaddr_in server, client;
    memset(&server, 0, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(PORT);
    server.sin_addr.s_addr = INADDR_ANY;

    if (bind(serverSock, (sockaddr*)&server, sizeof(server)) < 0) {
        cout << "Bind failed!" << endl;
        close(serverSock);
        return;
    }
    listen(serverSock, 5);
    cout << "TCP Server is waiting for client on port " << PORT << "..." << endl;

    socklen_t clientSize = sizeof(client);
    int clientSock = accept(serverSock, (sockaddr*)&client, &clientSize);
    if (clientSock < 0) {
        cout << "Accept failed!" << endl;
        close(serverSock);
        return;
    }
    cout << "Client connected: " << inet_ntoa(client.sin_addr)
         << ":" << ntohs(client.sin_port) << endl;

    char buffer[1024];
    while (true) {
        int bytes = recv(clientSock, buffer, 1023, 0);
        if (bytes <= 0)
            break;
        buffer[bytes] = '\0';
        cout << "Client: " << buffer << endl;

        if (string(buffer) == "exit")
            break;

        string reply = "Message received by TCP server";
        send(clientSock, reply.c_str(), reply.length(), 0);
    }

    close(clientSock);
    close(serverSock);
    cout << "TCP connection closed." << endl;
}

void udpServer() {
    int serverSock = socket(AF_INET, SOCK_DGRAM, 0);
    if (serverSock < 0) {
        cout << "Socket creation failed!" << endl;
        return;
    }

    int opt = 1;
    setsockopt(serverSock, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    sockaddr_in server, client;
    memset(&server, 0, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(PORT);
    server.sin_addr.s_addr = INADDR_ANY;

    if (bind(serverSock, (sockaddr*)&server, sizeof(server)) < 0) {
        cout << "Bind failed!" << endl;
        close(serverSock);
        return;
    }
    cout << "UDP Server is waiting for messages on port " << PORT << "..." << endl;

    char buffer[1024];
    while (true) {
        socklen_t clientSize = sizeof(client);
        int bytes = recvfrom(serverSock, buffer, 1023, 0,
                             (sockaddr*)&client, &clientSize);
        if (bytes < 0)
            break;
        buffer[bytes] = '\0';
        cout << "Client " << inet_ntoa(client.sin_addr) << ": " << buffer << endl;

        string reply = "Message received by UDP server";
        sendto(serverSock, reply.c_str(), reply.length(), 0,
               (sockaddr*)&client, clientSize);

        if (string(buffer) == "exit")
            break;
    }

    close(serverSock);
    cout << "UDP server closed." << endl;
}

int main() {
    int choice;
    do {
        cout << "\n===== SERVER MENU =====" << endl;
        cout << "1. TCP Server" << endl;
        cout << "2. UDP Server" << endl;
        cout << "3. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 1)
            tcpServer();
        else if (choice == 2)
            udpServer();
        else if (choice != 3)
            cout << "Invalid choice, try again." << endl;
    } while (choice != 3);

    return 0;
}
