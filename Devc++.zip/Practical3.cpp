#include <iostream>
#include <string>
using namespace std;

void parityCheck() {
    string data, received;
    int count = 0;

    cout << "Enter data bits: ";
    cin >> data;

    for (int i = 0; i < data.length(); i++) {
        if (data[i] == '1')
            count++;
    }

    cout << "Parity bit = " << count % 2 << endl;
    cout << "Transmitted data: " << data << count % 2 << endl;

    cout << "Enter received data bits including parity bit: ";
    cin >> received;

    count = 0;
    for (int i = 0; i < received.length(); i++) {
        if (received[i] == '1')
            count++;
    }

    if (count % 2 == 0)
        cout << "No error detected." << endl;
    else
        cout << "Single bit error detected (cannot be corrected)." << endl;
}

void xorOperation(string &data, string generator, int pos) {
    for (int i = 0; i < generator.length(); i++) {
        if (data[pos + i] == generator[i])
            data[pos + i] = '0';
        else
            data[pos + i] = '1';
    }
}

void crc(string &data, string generator) {
    int dataLen = data.length();
    int genLen = generator.length();

    for (int i = 0; i <= dataLen - genLen; i++) {
        if (data[i] == '1')
            xorOperation(data, generator, i);
    }
}

bool hasError(string code, string generator) {
    int len = code.length();
    int genLen = generator.length();

    crc(code, generator);

    for (int i = len - (genLen - 1); i < len; i++) {
        if (code[i] != '0')
            return true;
    }

    return false;
}

void crcCheck() {
    string data, generator, temp, remainder, codeword, received;

    cout << "Enter data bits: ";
    cin >> data;

    cout << "Enter generator: ";
    cin >> generator;

    int dataLen = data.length();
    int genLen = generator.length();

    temp = data;
    for (int i = 0; i < genLen - 1; i++)
        temp += '0';

    cout << "Data after appending zeros: " << temp << endl;

    crc(temp, generator);

    remainder = temp.substr(dataLen);
    cout << "CRC remainder: " << remainder << endl;

    codeword = data + remainder;
    cout << "Transmitted codeword: " << codeword << endl;

    cout << "Enter received codeword: ";
    cin >> received;

    if (hasError(received, generator))
        cout << "Error detected!" << endl;
    else
        cout << "No error detected." << endl;
}

void hammingCode() {
    string data, received;
    int m, r = 0, totalBits, errorPosition = 0;
    int hamming[200];

    cout << "Enter data bits: ";
    cin >> data;

    m = data.length();

    while ((1 << r) < (m + r + 1))
        r++;

    totalBits = m + r;

    for (int i = 1; i <= totalBits; i++)
        hamming[i] = 0;

    int j = 0;
    for (int i = 1; i <= totalBits; i++) {
        if ((i & (i - 1)) != 0) {
            hamming[i] = data[j] - '0';
            j++;
        }
    }

    for (int i = 0; i < r; i++) {
        int parityPosition = 1 << i;
        int parity = 0;

        for (j = 1; j <= totalBits; j++) {
            if (j & parityPosition)
                parity ^= hamming[j];
        }

        hamming[parityPosition] = parity;
    }

    cout << "Number of parity bits: " << r << endl;

    cout << "Generated Hamming code: ";
    for (int i = totalBits; i >= 1; i--)
        cout << hamming[i];
    cout << endl;

    cout << "Enter received Hamming code: ";
    cin >> received;

    if (received.length() != totalBits) {
        cout << "Invalid length." << endl;
        return;
    }

    for (int i = 1; i <= totalBits; i++)
        hamming[i] = received[totalBits - i] - '0';

    for (int i = 0; i < r; i++) {
        int parityPosition = 1 << i;
        int parity = 0;

        for (j = 1; j <= totalBits; j++) {
            if (j & parityPosition)
                parity ^= hamming[j];
        }

        if (parity)
            errorPosition += parityPosition;
    }

    if (errorPosition == 0) {
        cout << "No error detected." << endl;
    } else if (errorPosition <= totalBits) {
        cout << "Error detected at bit position: " << errorPosition << endl;

        hamming[errorPosition] ^= 1;

        cout << "Corrected Hamming code: ";
        for (int i = totalBits; i >= 1; i--)
            cout << hamming[i];
        cout << endl;
    } else {
        cout << "Multiple errors detected." << endl;
        return;
    }

    cout << "Corrected data bits: ";
    for (int i = totalBits; i >= 1; i--) {
        if ((i & (i - 1)) != 0)
            cout << hamming[i];
    }
    cout << endl;
}

int main() {
    int choice;

    do {
        cout << "\nERROR DETECTION AND CORRECTION" << endl;
        cout << "1. Parity Check" << endl;
        cout << "2. Cyclic Redundancy Check (CRC)" << endl;
        cout << "3. Hamming Code" << endl;
        cout << "4. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> choice;

        cout << endl;

        switch (choice) {
            case 1:
                parityCheck();
                break;
            case 2:
                crcCheck();
                break;
            case 3:
                hammingCode();
                break;
            case 4:
                cout << "Exiting program..." << endl;
                break;
            default:
                cout << "Invalid choice! Try again." << endl;
        }
    } while (choice != 4);

    return 0;
}